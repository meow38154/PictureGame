
using MapSystem;
using UnityEngine;

public class PlayerPartFollower : MonoBehaviour
{
    [Header("References")]
    [SerializeField] private Collider2D playerCollider;

    [Header("Detection")]
    [SerializeField] private LayerMask mapPieceLayer;
    [SerializeField, Min(0.01f)] private float groundCheckDistance = 0.15f;

    private MapPiece _currentPart;
    private Vector3 _lastPartPosition;

    private void Awake()
    {
        if (playerCollider == null)
            playerCollider = GetComponent<Collider2D>();
    }

    private void FixedUpdate()
    {
        DetectPart();
    }

    private void LateUpdate()
    {
        FollowPart();
    }

    private void DetectPart()
    {
        if (playerCollider == null)
            return;

        Bounds bounds = playerCollider.bounds;

        float y = bounds.min.y + 0.05f;
        float offset = bounds.extents.x * 0.7f;

        Vector2 center = new Vector2(bounds.center.x, y);

        MapPiece detectedPart =
            GetPartBelow(center) ??
            GetPartBelow(center + Vector2.left * offset) ??
            GetPartBelow(center + Vector2.right * offset);

        if (_currentPart == detectedPart)
            return;

        _currentPart = detectedPart;

        if (_currentPart != null)
            _lastPartPosition = _currentPart.transform.position;
    }

    private MapPiece GetPartBelow(Vector2 origin)
    {
        RaycastHit2D hit = Physics2D.Raycast(
            origin,
            Vector2.down,
            groundCheckDistance,
            mapPieceLayer);

        if (hit.collider == null || hit.normal.y < 0.5f)
            return null;

        return hit.collider.GetComponentInParent<MapPiece>();
    }

    private void FollowPart()
    {
        if (_currentPart == null)
            return;

        Vector3 currentPosition = _currentPart.transform.position;

        Vector3 delta = currentPosition - _lastPartPosition;

        if (delta.sqrMagnitude > 0f)
            transform.position += delta;

        _lastPartPosition = currentPosition;
    }
}
